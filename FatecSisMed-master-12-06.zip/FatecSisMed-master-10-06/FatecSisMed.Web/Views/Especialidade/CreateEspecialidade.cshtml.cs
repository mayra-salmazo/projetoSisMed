using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecSisMed.Web.Views.Especialidade
{
    public class CreateEspecialidadeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
