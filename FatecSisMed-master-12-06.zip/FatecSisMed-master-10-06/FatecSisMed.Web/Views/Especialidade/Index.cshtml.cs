using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecSisMed.Web.Views.Especialidade
{
    public class IndexEspecialidadeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
