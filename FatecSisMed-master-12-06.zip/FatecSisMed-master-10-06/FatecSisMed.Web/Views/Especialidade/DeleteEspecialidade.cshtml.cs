using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecSisMed.Web.Views.Especialidade
{
    public class DeleteEspecialidadeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
