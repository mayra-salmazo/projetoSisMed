using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecSisMed.Web.Views.Convenio
{
    public class UpdateConvenioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
