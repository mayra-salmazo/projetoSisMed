using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecSisMed.Web.Views.Convenio
{
    public class DeleteConvenioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
