using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecSisMed.Web.Views.Convenio
{
    public class IndexConvenioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
